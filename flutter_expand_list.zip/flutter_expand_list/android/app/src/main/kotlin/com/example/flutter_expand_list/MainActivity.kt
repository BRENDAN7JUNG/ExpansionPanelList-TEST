package com.example.flutter_expand_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
