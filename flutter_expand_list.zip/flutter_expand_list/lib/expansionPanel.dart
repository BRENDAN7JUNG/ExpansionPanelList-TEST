import 'package:flutter/material.dart';

class TestPanel extends StatefulWidget {
  TestPanelState createState() =>  TestPanelState();
}

class NewItem {
  bool isExpanded;
  final String header;
  final Widget body;
  final Icon iconpic;
  NewItem(this.isExpanded, this.header, this.body, this.iconpic);
}

class TestPanelState extends State<TestPanel> {
  int _iSelected;
  List<NewItem> items;
  String str_Heart_01;
  String str_Heart_02;

  void initHeartImage(){
    str_Heart_01 = "heart_on";
    str_Heart_02 = "heart_off";
  }

  void changeImage_01() {
    setState(() {
      str_Heart_01 = "heart_on";
      str_Heart_02 = "heart_off";
      print('[changeImage_01] $str_Heart_01');
    });
  }

  void changeImage_02() {
    setState(() {
      str_Heart_01 = "heart_off";
      str_Heart_02 = "heart_on";
      print('[changeImage_02] $str_Heart_02');
    });
  }

  @override
  void initState() {
    super.initState();

    _iSelected = 0;

    initHeartImage();

    items = <NewItem>[
      NewItem(
          false,
          'Sports',
          Padding(
              padding: EdgeInsets.all(20.0),
              child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Radio(value: 0, groupValue: _iSelected, onChanged: (int iValue){
                          setState((){
                            _iSelected = iValue;
                            print('00000=>$_iSelected');
                          });
                        }),
                        Expanded(child: Text('Tennis is a racket sport that can be played individually against a single opponent (singles) or between two teams of two players each (doubles).'),),
                      ],
                    ),  //put the children here
                    Row(
                      children: <Widget>[
                        Radio(value: 1, groupValue: _iSelected, onChanged: (int iValue){
                          setState(() {
                            _iSelected = iValue;
                            print('11111=>$_iSelected');
                          });
                        }),
                        Expanded(child: Text('Football is played in accordance with a set of rules known as the Laws of the Game. The ball is 68–70 cm (27–28 in) in circumference and known as the football. '),),
                      ],
                    ),  //put the children here
                    Row(
                      children: <Widget>[
                        Radio(value: 2, groupValue: _iSelected, onChanged: (int iValue){
                          setState((){
                            _iSelected = iValue;
                            print('22222=>$_iSelected');
                          });
                        }),
                        Expanded(child: Text('Golf is a club-and-ball sport in which players use various clubs to hit balls into a series of holes on a course in as few strokes as possible.'),),
                      ],
                    ),  //put the children here
                  ]
              )
          ),
          Icon(Icons.image)
      ),
      NewItem(
          false,
          'Music-Image Change',
          Padding(
              padding: EdgeInsets.all(20.0),
              child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        InkWell(
                          onTap: () => changeImage_01(),
                          child: Image.asset(
                            'assets/images/$str_Heart_01.png',
                            height: 30,
                            width: 30,
                          ),
                        ),
                        SizedBox(width:10, height:10),
                        Expanded(
                          child: Text(
                              'Rock music is a broad genre of popular music that originated as rock and roll in the United States in the late 1940s and early 1950s,'),
                        ),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        InkWell(
                          onTap: () => changeImage_02(),
                          child: Image.asset(
                            'assets/images/$str_Heart_02.png',
                            height: 30,
                            width: 30,
                          ),
                        ),
                        SizedBox(width:10, height:10),
                        Expanded(
                          child: Text(
                              'Jazz is a music genre that originated in the African-American communities of New Orleans, United States in the late 19th and early 20th centuries, with its roots in blues and ragtime'),
                        ),
                      ],
                    ),
                  ]
              )
          ),
          Icon(Icons.image)
      ),
    ];
  }



  ListView List_Criteria;

  Widget build(BuildContext context) {
    List_Criteria = ListView(
      children: [
         Padding(
          padding:  EdgeInsets.all(10.0),
          child:  ExpansionPanelList(
            expansionCallback: (int index, bool isExpanded) {
              setState(() {
                items[index].isExpanded = !items[index].isExpanded;
              });
            },
            children: items.map((NewItem item) {
              return ExpansionPanel(
                headerBuilder: (BuildContext context, bool isExpanded) {
                  return  ListTile(
                    leading: item.iconpic,
                    title:  Text(
                      item.header,
                      textAlign: TextAlign.left,
                      style:  TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.w400,
                      ),
                    )
                  );
                },
                isExpanded: item.isExpanded,
                body: item.body,
              );
            }).toList(),
          ),
        ),
      ],
    );

    Scaffold scaffold =  Scaffold(
      appBar:  AppBar(
        title:  Text("ExpansionPanelList"),
      ),
      body: List_Criteria,
    );
    return scaffold;
  }
}